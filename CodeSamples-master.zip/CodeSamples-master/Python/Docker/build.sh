sudo docker build -t dockerfile:latest .

sudo docker run -d -p 5000:5000 dockerfile

sudo docker logs instancieidhere

sudo docker ps

sudo docker stop instancieidhere

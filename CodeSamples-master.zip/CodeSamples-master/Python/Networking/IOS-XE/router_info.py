router = {"host": "ios-xe-mgmt-latest.cisco.com",
          "port": "10000",
          "username": "developer",
          "password": "C1sco12345"}
